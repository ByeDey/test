package notice.controller;

import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

@Controller
public class FileUploadController {

	private static final String GITHUB_API_URL = "https://api.github.com/repos/ByeDey/test/contents/";

	// �솚寃� 蹂��닔�뿉�꽌 GitHub �넗�겙�쓣 �븞�쟾�븯寃� 遺덈윭�샃�땲�떎.
	private static final String GITHUB_TOKEN = "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";  // �솚寃� 蹂��닔�뿉�꽌 GitHub Token�쓣 遺덈윭�샃�땲�떎.  

	@ResponseBody
	public String uploadFile(@RequestParam("file") MultipartFile file, HttpServletResponse response) {
		System.out.println("file : " + file);

		// �쓳�떟�쓽 臾몄옄 �씤肄붾뵫�쓣 UTF-8濡� �꽕�젙
		response.setContentType("application/json; charset=UTF-8");

		if (file.isEmpty()) {
			return "{\"message\": \"�뙆�씪�씠 鍮꾩뼱 �엳�뒿�땲�떎.\"}";
		}

		try {
			// �쁽�옱 �궇吏쒖� �떆媛꾩쓣 "yyyy-MM-dd_HH-mm-ss" �삎�떇�쑝濡� �룷留�
			String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());


			// 湲곗〈 �뙆�씪 �씠由꾧낵 �쁽�옱 �떆媛꾩쓣 寃고빀�븯�뿬 �깉 �뙆�씪 �씠由� �깮�꽦
			String newFileName = timeStamp + "_" + file.getOriginalFilename();

			// �뙆�씪�쓣 Base64濡� �씤肄붾뵫
			byte[] fileContent = file.getBytes();
			String encodedContent = Base64.getEncoder().encodeToString(fileContent);

			// GitHub�뿉 �뾽濡쒕뱶�븯怨�, GitHub�뿉 ���옣�맂 �뙆�씪紐낆쓣 諛섑솚
			String githubFileName = uploadToGitHub(newFileName, encodedContent);

			// 諛섑솚�맂 GitHub�뿉 ���옣�맂 �뙆�씪紐낆쑝濡� �썑�냽 �옉�뾽 �닔�뻾
			return newFileName;
		} catch (Exception e) {
			return "{\"message\": \"�뙆�씪 �뾽濡쒕뱶 �떎�뙣: " + e.getMessage() + "\"}";
		}
	}


	private String uploadToGitHub(String fileName, String encodedContent) {
		String filePath = "uploads/" + fileName; // GitHub�뿉 ���옣�븷 �뙆�씪 寃쎈줈

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + GITHUB_TOKEN);  // �넗�겙�� 'Bearer'濡� �씠�뼱�빞 �빀�땲�떎
		headers.setContentType(MediaType.APPLICATION_JSON);

		// GitHub API�뿉 蹂대궡�뒗 JSON �뜲�씠�꽣
		String jsonBody = "{"
				+ "\"message\": \"Add " + fileName + "\"," 
				+ "\"content\": \"" + encodedContent + "\","
				+ "\"path\": \"" + filePath + "\""
				+ "}";
 
		HttpEntity<String> entity = new HttpEntity<String>(jsonBody, headers);
		RestTemplate restTemplate = new RestTemplate();

		// GitHub API�뿉 PUT �슂泥�
		ResponseEntity<String> response = restTemplate.exchange(GITHUB_API_URL + filePath, HttpMethod.PUT, entity, String.class);
		return response.getBody();
	}
}
